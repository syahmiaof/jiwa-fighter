/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    unoptimized: true, // Guarantees local webp/png fast serving without external server dependencies
  },
};

export default nextConfig;
