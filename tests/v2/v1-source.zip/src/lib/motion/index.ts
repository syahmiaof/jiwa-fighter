'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

// Safe registration in browser only
if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger, useGSAP);
}

export function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches ?? false
  );
}

/**
 * Clean entrance animation for hero elements:
 * 1. Initial calm state
 * 2. Decisive staggered reveal with disciplined easing
 * 3. Soft settling
 */
export function useHeroReveal<T extends HTMLElement = HTMLDivElement>() {
  const containerRef = useRef<T>(null);

  useGSAP(
    () => {
      if (prefersReducedMotion() || !containerRef.current) return;

      const tl = gsap.timeline({
        defaults: { ease: 'power3.out' },
        onComplete: () => {
          if (containerRef.current) {
            gsap.set(
              containerRef.current.querySelectorAll(
                '.hero-kicker, .hero-headline, .hero-subtext, .hero-cta, .hero-image'
              ),
              { clearProps: 'transform,opacity,filter' }
            );
          }
        },
      });

      tl.fromTo(
        '.hero-kicker',
        { opacity: 0, y: -8 },
        { opacity: 1, y: 0, duration: 0.35, delay: 0.05 }
      )
        .fromTo(
          '.hero-headline',
          { opacity: 0, y: 18 },
          { opacity: 1, y: 0, duration: 0.45 },
          '-=0.2'
        )
        .fromTo(
          '.hero-subtext',
          { opacity: 0, y: 10 },
          { opacity: 1, y: 0, duration: 0.35 },
          '-=0.2'
        )
        .fromTo(
          '.hero-cta',
          { opacity: 0, scale: 0.98 },
          { opacity: 1, scale: 1, duration: 0.3 },
          '-=0.15'
        )
        .fromTo(
          '.hero-image',
          { opacity: 0, scale: 1.02 },
          { opacity: 1, scale: 1, duration: 0.5, ease: 'power2.out' },
          0.05
        );
    },
    { scope: containerRef }
  );

  return containerRef;
}

/**
 * Standard scroll reveal for content sections.
 */
export function useScrollReveal<T extends HTMLElement = HTMLDivElement>(
  selector = '.reveal-item',
  stagger = 0.06
) {
  const containerRef = useRef<T>(null);

  useGSAP(
    () => {
      if (prefersReducedMotion() || !containerRef.current) return;

      const items = containerRef.current.querySelectorAll(selector);
      if (!items.length) return;

      gsap.from(items, {
        opacity: 0,
        y: 18,
        duration: 0.45,
        stagger,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top 95%',
          toggleActions: 'play none none none',
          once: true,
        },
      });
    },
    { scope: containerRef }
  );

  return containerRef;
}

/**
 * Stagger entrance for card grids.
 */
export function useStaggerCards<T extends HTMLElement = HTMLDivElement>(
  cardSelector = '.stagger-card'
) {
  const containerRef = useRef<T>(null);

  useGSAP(
    () => {
      if (prefersReducedMotion() || !containerRef.current) return;

      const cards = containerRef.current.querySelectorAll(cardSelector);
      if (!cards.length) return;

      gsap.from(cards, {
        opacity: 0,
        y: 20,
        scale: 0.98,
        duration: 0.45,
        stagger: 0.08,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top 95%',
          once: true,
        },
      });
    },
    { scope: containerRef }
  );

  return containerRef;
}
