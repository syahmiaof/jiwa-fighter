'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import {
  Search,
  ArrowRight,
  Plus,
  Minus,
  Shirt,
  Package,
  Users,
  CheckCircle2,
} from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { useHeroReveal, useScrollReveal } from '@/lib/motion';

export default function SupportPage() {
  const { t } = useLanguage();
  const heroRef = useHeroReveal<HTMLDivElement>();
  const middleRef = useScrollReveal<HTMLDivElement>('.support-block', 0.1);

  // States
  const [activeCategory, setActiveCategory] = useState<'orders' | 'shipping' | 'sizing' | 'teamwear'>('orders');
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState('');

  // Contact Form State
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const categories = [
    { id: 'orders', label: t.support.tabOrders },
    { id: 'shipping', label: t.support.tabShipping },
    { id: 'sizing', label: t.support.tabSizing },
    { id: 'teamwear', label: t.support.tabTeamwear },
  ];

  const faqData = {
    orders: [
      {
        q: 'How do I choose my size?',
        a: 'Our combat jerseys feature an athletic tailored silhouette. We recommend selecting your true standard tee size for a performance fit, or one size larger for a relaxed lifestyle aesthetic. Refer to our Size & Fit Guide for exact chest measurements.',
      },
      {
        q: 'How can I track an order?',
        a: 'In this prototype version, tracking codes are simulated. In production, an instant tracking link with your designated courier (DHL Express / J&T) will be dispatched directly to your confirmed email.',
      },
      {
        q: 'What is your return policy?',
        a: 'We offer an exchange window of 14 calendar days from delivery date for unused, unwashed garments retaining all original tags and packaging.',
      },
      {
        q: 'Can my club request custom jerseys?',
        a: 'Yes. Visit our Custom Teamwear section (/custom) to submit kit specifications, club insignias, and required quantities starting from 10 pieces.',
      },
    ],
    shipping: [
      {
        q: 'What are domestic delivery timelines?',
        a: 'Standard delivery across Peninsular Malaysia is 2 to 4 working days. Deliveries to Sabah & Sarawak typically require 3 to 6 working days.',
      },
      {
        q: 'Do you ship internationally?',
        a: 'Yes, international delivery is available across Southeast Asia, Australia, the UK, and the USA via express air freight.',
      },
    ],
    sizing: [
      {
        q: 'Are the fabrics pre-shrunk?',
        a: 'Yes, all JIWA FIGHTER poly-spandex and heavyweight French Terry items undergo pre-treatment shrinkage stabilization to ensure long-term dimensional retention.',
      },
      {
        q: 'What if my measurements fall between two sizes?',
        a: 'For athletic sparring and compression performance, choose the smaller size. For casual lifestyle wear, select the larger size.',
      },
    ],
    teamwear: [
      {
        q: 'What is the minimum order quantity (MOQ) for custom teamwear?',
        a: 'Our minimum club batch size is 10 jerseys with full custom team name, crest, and numbering sublimation.',
      },
      {
        q: 'How long does custom kit production take?',
        a: 'Standard manufacturing turnaround is 14 to 21 working days after final vector artwork sign-off.',
      },
    ],
  };

  const currentFaqs = faqData[activeCategory] || faqData.orders;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  return (
    <div className="w-full bg-bone text-obsidian min-h-screen">
      {/* 1. TOP HERO SECTION */}
      <section
        ref={heroRef}
        className="relative min-h-[420px] md:min-h-[480px] flex items-center bg-bone border-b border-bone-border overflow-hidden"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 w-full h-full">
          {/* Left: Typography & Help Search (7 cols) */}
          <div className="lg:col-span-7 p-8 sm:p-12 lg:p-16 flex flex-col justify-center space-y-5">
            <div className="hero-kicker flex items-center gap-3">
              <span className="text-xs font-mono tracking-widestEditorial uppercase text-text-muted-dark">
                {t.support.kicker}
              </span>
              <div className="h-[1px] w-12 bg-brass" />
            </div>

            <h1 className="hero-headline font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-obsidian tracking-tighterEditorial leading-[0.9] uppercase">
              {t.support.headline}
            </h1>

            <p className="hero-subtext text-xs sm:text-sm font-sans text-text-muted-dark">
              {t.support.subtext}
            </p>

            {/* Search Input Bar */}
            <div className="hero-cta pt-3 max-w-lg">
              <div className="flex items-center border border-obsidian/30 bg-bone-card/60 px-4 py-3 focus-within:border-obsidian transition-colors">
                <Search className="w-4 h-4 text-text-muted-dark mr-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.support.searchPlaceholder}
                  className="w-full bg-transparent text-xs font-mono tracking-wider text-obsidian placeholder-text-muted-dark focus:outline-none uppercase"
                />
                <button
                  type="button"
                  className="text-obsidian hover:text-brass transition-colors p-1"
                  aria-label="Submit search"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Right: Athlete in Training Hall (5 cols) */}
          <div className="lg:col-span-5 relative min-h-[300px] lg:min-h-full bg-obsidian">
            <Image
              src="/assets/campaigns/support-hero-athlete.webp"
              alt="Support Hero Athlete"
              fill
              priority
              className="object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-obsidian/50 via-transparent to-transparent" />
          </div>
        </div>
      </section>

      {/* 2. MIDDLE SECTION: FAQ & CONTACT FORM */}
      <section ref={middleRef} className="max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8 py-14 md:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 xl:gap-14 items-start">
          {/* Left: FAQ List (7 cols) */}
          <div className="support-block lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono tracking-widestEditorial uppercase text-brass font-bold">
                  {t.support.faqKicker}
                </span>
                <div className="h-[1px] w-12 bg-brass" />
              </div>
              <h2 className="font-display text-4xl sm:text-5xl text-obsidian uppercase">
                {t.support.faqTitle}
              </h2>
            </div>

            {/* Category Pills */}
            <div className="flex flex-wrap gap-2 pt-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setActiveCategory(cat.id as any);
                    setOpenFaq(0);
                  }}
                  className={`px-4 py-2 text-xs font-mono tracking-widest uppercase transition-all ${
                    activeCategory === cat.id
                      ? 'bg-brass text-obsidian font-bold shadow'
                      : 'bg-bone-card border border-bone-border hover:border-obsidian text-obsidian'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Accordion Questions */}
            <div className="space-y-3 pt-4">
              {currentFaqs.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={idx}
                    className="border-b border-bone-border pb-4 transition-all"
                  >
                    <button
                      onClick={() => setOpenFaq(isOpen ? null : idx)}
                      className="w-full flex items-center justify-between py-2 text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-mono text-brass font-bold">
                          {`0${idx + 1}`}
                        </span>
                        <span className="font-display text-lg sm:text-xl text-obsidian group-hover:text-brass transition-colors tracking-wide">
                          {faq.q}
                        </span>
                      </div>
                      <div className="p-1 text-obsidian group-hover:text-brass transition-colors shrink-0">
                        {isOpen ? <Minus className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                      </div>
                    </button>

                    {isOpen && (
                      <div className="pt-2 pl-7 pr-4 text-xs sm:text-sm font-sans text-text-muted-dark leading-relaxed animate-fade-in">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Dark Contact Box (5 cols) */}
          <div className="support-block lg:col-span-5 bg-obsidian text-bone p-8 sm:p-10 border border-brass/40 shadow-xl space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-mono tracking-widest uppercase text-brass">
                {t.support.contactKicker}
              </span>
              <h3 className="font-display text-3xl sm:text-4xl text-bone uppercase">
                {t.support.contactTitle}
              </h3>
              <p className="text-xs text-bone/70 font-sans leading-relaxed">
                {t.support.contactDesc}
              </p>
            </div>

            {isSubmitted ? (
              <div className="p-5 bg-obsidian-subtle border border-brass/40 space-y-3 animate-fade-in">
                <div className="flex items-center gap-2 text-brass">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span className="font-display text-lg uppercase tracking-wider">
                    MESSAGE SIMULATED
                  </span>
                </div>
                <p className="text-xs text-bone/70 font-mono leading-relaxed">
                  {t.support.demoAlert}
                </p>
                <button
                  onClick={() => {
                    setIsSubmitted(false);
                    setFormData({ name: '', email: '', message: '' });
                  }}
                  className="w-full py-2 bg-brass text-obsidian text-xs font-display tracking-widest uppercase"
                >
                  SEND ANOTHER MESSAGE
                </button>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-4 text-xs font-mono">
                <div className="space-y-1.5">
                  <label className="block text-bone/80 uppercase">
                    {t.support.nameLabel}
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full p-3 bg-obsidian border border-obsidian-border focus:border-brass text-bone focus:outline-none transition-colors"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-bone/80 uppercase">
                    {t.support.emailLabel}
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full p-3 bg-obsidian border border-obsidian-border focus:border-brass text-bone focus:outline-none transition-colors"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-bone/80 uppercase">
                    {t.support.messageLabel}
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full p-3 bg-obsidian border border-obsidian-border focus:border-brass text-bone focus:outline-none transition-colors"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-brass hover:bg-brass-light text-obsidian font-display tracking-widest text-sm uppercase transition-colors flex items-center justify-center gap-2 font-semibold"
                >
                  <span>{t.support.sendEnquiry}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <p className="text-[10px] text-bone/40 text-center font-mono">
                  DEMO PROTOCOL — Simulated contact interface.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* 3. BOTTOM THREE VALUE PROPS */}
      <section className="border-t border-bone-border py-12 bg-bone">
        <div className="max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-bone-card border border-bone-border text-obsidian shrink-0">
                <Shirt className="w-6 h-6 text-brass" />
              </div>
              <div className="space-y-1">
                <h3 className="font-display text-base tracking-wider uppercase text-obsidian">
                  {t.support.pillar1Title}
                </h3>
                <p className="text-xs text-text-muted-dark font-sans leading-relaxed">
                  {t.support.pillar1Desc}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-bone-card border border-bone-border text-obsidian shrink-0">
                <Package className="w-6 h-6 text-brass" />
              </div>
              <div className="space-y-1">
                <h3 className="font-display text-base tracking-wider uppercase text-obsidian">
                  {t.support.pillar2Title}
                </h3>
                <p className="text-xs text-text-muted-dark font-sans leading-relaxed">
                  {t.support.pillar2Desc}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 bg-bone-card border border-bone-border text-obsidian shrink-0">
                <Users className="w-6 h-6 text-brass" />
              </div>
              <div className="space-y-1">
                <h3 className="font-display text-base tracking-wider uppercase text-obsidian">
                  {t.support.pillar3Title}
                </h3>
                <p className="text-xs text-text-muted-dark font-sans leading-relaxed">
                  {t.support.pillar3Desc}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
