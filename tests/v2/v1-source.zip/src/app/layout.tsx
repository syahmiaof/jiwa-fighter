import type { Metadata } from 'next';
import { Bebas_Neue, Inter } from 'next/font/google';
import '@/styles/globals.css';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';
import { CartProvider } from '@/lib/cart/CartContext';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { DemoModalWrapper } from '@/components/ui/DemoModalWrapper';

const bebasNeue = Bebas_Neue({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'JIWA FIGHTER — Iron Heritage Combatwear',
  description:
    'Premium Malaysian combatwear and heritage streetwear. Engineered for discipline, movement, and identity.',
  icons: {
    icon: '/assets/brand/emblem-brass.png',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${bebasNeue.variable} ${inter.variable}`}>
      <body className="bg-obsidian text-bone min-h-screen flex flex-col font-sans selection:bg-brass selection:text-obsidian">
        <LanguageProvider>
          <CartProvider>
            <Header />
            <main className="flex-1 w-full">{children}</main>
            <Footer />
            <CartDrawer />
            <DemoModalWrapper />
          </CartProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
