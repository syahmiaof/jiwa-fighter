'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { Search, ShoppingBag, Menu, X } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { useCart } from '@/lib/cart/CartContext';
import { SearchModal } from '@/components/search/SearchModal';

export const Header: React.FC = () => {
  const pathname = usePathname();
  const { language, setLanguage, t } = useLanguage();
  const { totalCount, openCart } = useCart();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: t.nav.shop, href: '/shop' },
    { label: t.nav.collections, href: '/collections/silat-series' },
    { label: t.nav.lookbook, href: '/lookbook' },
    { label: t.nav.ourStory, href: '/our-story' },
    { label: t.nav.custom, href: '/custom' },
  ];

  const isActive = (href: string) => {
    if (href === '/shop') return pathname === '/shop';
    if (href === '/collections/silat-series') return pathname.startsWith('/collections');
    return pathname === href;
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-obsidian border-b border-obsidian-border/80 transition-all">
        <div className="max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8 h-16 md:h-18 flex items-center justify-between">
          {/* Left: Brand Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative w-8 h-8 md:w-9 md:h-9 shrink-0">
              <Image
                src="/assets/brand/emblem-white.png"
                alt="Jiwa Fighter Emblem"
                fill
                priority
                className="object-contain transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <span className="font-display text-lg md:text-xl tracking-wider text-bone font-bold uppercase transition-colors group-hover:text-brass">
              JIWA FIGHTER
            </span>
          </Link>

          {/* Center: Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8 xl:gap-10">
            {navLinks.map((link) => {
              const active = isActive(link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`text-xs xl:text-sm font-medium tracking-widest uppercase transition-all relative py-1 ${
                    active
                      ? 'text-brass font-semibold'
                      : 'text-bone/80 hover:text-bone'
                  }`}
                >
                  {link.label}
                  {active && (
                    <span className="absolute bottom-0 left-0 w-full h-[2px] bg-brass animate-fade-in" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right: Controls & Actions */}
          <div className="flex items-center gap-4 sm:gap-6">
            {/* Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-1.5 text-bone/80 hover:text-brass transition-colors"
              aria-label="Search"
            >
              <Search className="w-4 h-4 md:w-5 md:h-5" />
            </button>

            {/* Language Switcher (EN / BM) */}
            <div className="flex items-center text-xs tracking-wider font-mono">
              <button
                onClick={() => setLanguage('en')}
                className={`transition-colors py-0.5 ${
                  language === 'en'
                    ? 'text-brass font-bold border-b border-brass'
                    : 'text-bone/50 hover:text-bone'
                }`}
              >
                EN
              </button>
              <span className="text-bone/30 mx-1.5">/</span>
              <button
                onClick={() => setLanguage('bm')}
                className={`transition-colors py-0.5 ${
                  language === 'bm'
                    ? 'text-brass font-bold border-b border-brass'
                    : 'text-bone/50 hover:text-bone'
                }`}
              >
                BM
              </button>
            </div>

            {/* Bag Icon & Counter */}
            <button
              onClick={openCart}
              className="flex items-center gap-1.5 text-bone/80 hover:text-brass transition-colors p-1"
              aria-label="Open Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4 md:w-5 md:h-5" />
              <span className="font-mono text-xs font-bold text-bone">
                {totalCount.toString().padStart(2, '0')}
              </span>
            </button>

            {/* Mobile Hamburger Menu */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-1.5 text-bone/80 hover:text-brass transition-colors ml-1"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-brass" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-obsidian-border bg-obsidian-subtle/95 backdrop-blur-md px-6 py-6 animate-fade-in">
            <nav className="flex flex-col gap-4">
              {navLinks.map((link) => {
                const active = isActive(link.href);
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`text-base font-display tracking-widest uppercase transition-colors ${
                      active ? 'text-brass' : 'text-bone hover:text-brass'
                    }`}
                  >
                    {link.label}
                  </Link>
                );
              })}
              <div className="pt-4 border-t border-obsidian-border flex flex-col gap-2">
                <Link
                  href="/size-guide"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-xs text-bone/60 hover:text-brass uppercase tracking-widest font-mono"
                >
                  Size & Fit Guide
                </Link>
                <Link
                  href="/support"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-xs text-bone/60 hover:text-brass uppercase tracking-widest font-mono"
                >
                  Customer Support & FAQ
                </Link>
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* Global Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />
    </>
  );
};
